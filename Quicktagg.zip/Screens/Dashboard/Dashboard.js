import moment from "moment";
import React, { useState, useEffect, useRef } from "react";
import { Pressable } from "react-native";
import { ImageBackground, View, ScrollView, FlatList, Image, Alert } from "react-native";
import {
  Button,
  Card,
  IconButton,
  TextInput,
  Text,
  DataTable,
  Modal,
  Surface,
  Portal,
  List,
} from "react-native-paper";
import Swiper from "react-native-swiper";
import HTML from "react-native-render-html";
import * as ScreenOrientation from 'expo-screen-orientation';
import * as Animatable from "react-native-animatable";
import CustomModal from "../../Components/CustomModal";
import DropDown from "../../Components/DropDown";
import Header from "../../Components/Header";
import ImageUpload from "../../Components/ImageUpload";
import { postRequest, uploadImage } from "../../Services/RequestServices";
import MyStyles from "../../Styles/MyStyles";
import DatePicker from "../../Components/DatePicker";
import RedeemModal from "./RedeemModal";
import * as ImagePicker from "expo-image-picker";
import UploadModal from "./UploadModal";
import { serviceUrl, imageUrl } from "../../Services/Constants";
const Dashboard = (props) => {
  const { branchId, branchName, logoPath, token } = props.loginDetails;
  const imageRef = useRef(null);
  // const [category, setCategory] = useState({
  //   scooter: false,
  //   motorcycle: true,
  // });
  const CATEGORY_IDS = {
    scooter: '2180',
    motorcycle: '2181',
    bike: '2182',
  };
  
  const [category, setCategory] = useState({
    scooter: false,
    motorcycle: false,
    bike: false,
  });
  
  const [payloadData, setPayloadData] = useState([]);
  
  const categoryImage = {
    scooter: "https://api.quicktagg.com/CustomerUploads/image-3c8744d8-9bd3-493a-bfb4-8c72cd086b18.png",
    motorcycle: "https://api.quicktagg.com/CustomerUploads/image-4301b3d1-b65e-483d-a1c2-470f005e9a7c.jpg",
    bike: "https://api.quicktagg.com/CustomerUploads/image-4301b3d1-b65e-483d-a1c2-470f005e9a7c.jpg",
  };
  const toggleCategory = (type) => {
    const isSelected = !category[type];
    const categoryId = CATEGORY_IDS[type];
  
    setCategory(prev => ({
      ...prev,
      [type]: isSelected,
    }));
  
    setPayloadData(prev => {
      const updated = [...prev];
  
      if (isSelected) {
        // Add a new payload for the selected category
        const newPayload = {
          tran_id: 0,
          customer_id: upload?.customer_id || 0,
          mobile: upload?.mobile || '',
          full_name: upload?.full_name || '',
          remarks: upload?.remarks || '',
          sku: upload?.sku || '',
          image_path: {"choose":"", "add":[], "fetchSku":"", "url":categoryImage[type]},
          appointment_date: upload?.appointment_date || '',
          payment: upload?.payment || '',
          sub_category: upload?.sub_category || '',
          interest: upload?.interest || 'Yes',
          staff_id: upload?.staff_id || '1069',
          category_id: categoryId? categoryId : '',
        };
  
        return [...updated, newPayload];
      } else {
        // OPTIONAL: Remove payloads for this category
        return updated.filter(item => item.category_id !== categoryId);
      }
    });
  };
  useEffect(() => {
    console.log("Updated payloadData:", payloadData);
  }, [payloadData]);
  
  
  const options = [
    { label: 'YES', value: 'yes' },
    { label: 'FOLLOW UP', value: 'followup' },
    { label: 'REQUIREMENT', value: 'requirement' },
  ];
  const [selectedImages, setSelectedImages] = useState([]);
  const [interest, setInterest] = useState('yes');
  const [details, setDetails] = useState(null);
  const [history, setHistory] = useState([]);
  const [tabs, setTabs] = useState(1);
  const [design, setDesign] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [exhibition, setExhibition] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [redeem, setRedeem] = useState(null);
  const [checkIn, setCheckIn] = useState(null);
  const [voucherList, setVoucherList] = useState(null);
  const [upload, setUpload] = useState(null);
  const [points, setPoints] = useState(null);
  const [customerId, setCustomerId] = useState(null);
  const [redeemPoints, setRedeemPoints] = useState(null);
  const [expiredPoints, setExpiredPoints] = useState(null);
  const [selectedFiles, setSelectedFiles] = useState([]);

  
    const [image, setImage] = useState([]);
  
    const pickImage = async () => {
      console.log("pickImage");
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true, // For multiple selection (if supported by platform)
      });
    
      console.log("result--->", result);
    
      if (!result.cancelled) {
        const uriList = result.selected ? result.selected.map(item => item.uri) : [result.uri];
    
        setImage((prevImages) => [...prevImages, ...uriList]);
      }
    };
    
    const handleUpload = async () => {
      if (!image || image.length === 0) {
        alert("Please select at least one image first.");
        return;
      }
    
      const formData = new FormData();
    
      image.forEach((uri, index) => {
        formData.append("images", {
          uri,
          type: "image/jpeg",
          name: `upload_${index}.jpg`,
        });
      });
    
      try {
        const response = await uploadImage("/upload", formData, token); // use actual route
        console.log("Upload response", response);
      } catch (error) {
        console.error("Upload failed", error);
      }
    };
    
  


  const subCategoryData =
    category === "SCOOTER"
      ? [
        { label: "JUPITER", value: "JUPITER" },
        { label: "PEP", value: "PEP" },
      ]
      : [
        { label: "APACHE", value: "APACHE" },
        { label: "SPORTS", value: "SPORTS" },
      ];
 

  const [join, setJoin] = useState({
    customer_id: "0",
    branch_id: branchId,

    full_name: "",
    mobile: "",
    gender: "",
    dob: "",
    doa: "",
    address: "",

    ref_id: "",
    category_id: "",
    staff_id: "",
    area_id: "",
    profession: "",

    step1: true,
  });
  const [modal, setModal] = useState({
    mobile: "",
    details: false,
    history: false,
    design: false,
    redeem: false,
    join: false,
    checkIn: false,
    upload: false,
    uploadNext: false,
    notification: false,
    area: false,
  });
  const [staffList, setStaffList] = useState([]);
  const [categoryList, setCategoryList] = useState([]);
  const [areaList, setAreaList] = useState([]);
  const [recentVistors, setRecentVistors] = useState([]);
  const [bannerImages, setBannerImages] = useState([]);
  const [imageUri, setImageUri] = useState(
    "https://api.quicktagg.com/tabBanner/image-d7e532c1-6f79-4f06-ae1d-9afd4567940f.jpg"
  );

  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    imageSwitch();
    postRequest("masters/customer/tabtoscanBannerBrowse", {}, token).then((res) => {
      if (!res || typeof res !== 'object' || res.status === undefined) {
        console.error("Invalid API response for tabtoscanBannerBrowse", res);
        // Optionally: setBannerImages([]); setImageUri(null);
        return;
      }
      if (res.status == 200) {
        const data = res.data.map((item) => item.url + item.image_path);
        setBannerImages(data);
        setImageUri(data[0]);
      }
    }).catch((err) => {
      console.error("API error (tabtoscanBannerBrowse):", err);
    });
    postRequest("customervisit/StaffList", {}, token).then((resp) => {
      if (!resp || typeof resp !== 'object' || resp.status === undefined) {
        console.error("Invalid API response for StaffList", resp);
        return;
      }
      if (resp.status == 200) {
        console.log("StaffList", resp.data);
        setStaffList(resp.data);
      }
    }).catch((err) => {
      console.error("API error (StaffList):", err);
    });
    postRequest("customervisit/CategoryList", {}, token).then((resp) => {
      if (!resp || typeof resp !== 'object' || resp.status === undefined) {
        console.error("Invalid API response for CategoryList", resp);
        return;
      }
      if (resp.status == 200) {
        console.log("CategoryList", resp.data);


      }
    }).catch((err) => {
      console.error("API error (CategoryList):", err);
    });
    postRequest("customervisit/AreaList", {}, token).then((resp) => {
      if (!resp || typeof resp !== 'object' || resp.status === undefined) {
        console.error("Invalid API response for AreaList", resp);
        return;
      }
      if (resp.status == 200) {
        setAreaList(resp.data);
      }
    }).catch((err) => {
      console.error("API error (AreaList):", err);
    });
  }, []);

  const imageSwitch = () => {
    var index = bannerImages.indexOf(imageUri);
    if (index >= bannerImages.length - 1) {
      index = -1;
    }
    // console.log(index);
    setImageUri(bannerImages[index + 1]);
    if (imageRef) {
      imageRef.current.animate({ 0: { opacity: 0 }, 1: { opacity: 1 } });
    }
  };

  // --UseEffect For Image Trigger--

  useEffect(() => {
    const ticket = setTimeout(imageSwitch, 20000);
    return () => {
      clearTimeout(ticket);
    };
  }, [imageUri]);

  // --UseEffect For Recent Visits--

  useEffect(() => {
    postRequest("customervisit/getRecentvisiters", {}, token).then((resp) => {
      if (!resp || typeof resp !== 'object' || resp.status === undefined) {
        console.error("Invalid API response for getRecentvisiters", resp);
        return;
      }
      if (resp.status == 200) {
        setRecentVistors(resp.data);
      }
    }).catch((err) => {
      console.error("API error (getRecentvisiters):", err);
    });
  }, [details, redeem, checkIn, upload, join]);

  return (
    // <ImageBackground
    //   source={{
    //     uri: imageUri,
    //   }}
    //   style={{ flex: 1, backgroundColor: "#000" }}
    //   imageStyle={{ opacity: 1 }}
    // >
    <View style={[MyStyles.container, { backgroundColor: "#000" }]}>
      {imageUri && (
        <Animatable.Image
          source={{
            uri: imageUri,
          }}
          style={{
            height: "100%",
            width: "100%",
            zIndex: -10,
            position: "absolute",
            top: 0,
            left: 0,
          }}
          ref={imageRef}
          duration={26000}
        />
      )}
      <Header
        logoPath={logoPath}
        right={
          <IconButton
            icon="bell"
            color={MyStyles.primaryColor.backgroundColor}
            size={23}
            onPress={() => {
              postRequest("customervisit/getNotification", {}, token).then((resp) => {
                console.log(resp);
                if (resp.status == 200) {
                  setNotifications(resp.data);
                  setModal({ ...modal, notification: true });
                }
              });
            }}
          />
        }
      />

      <View style={{ flex: 1, paddingBottom: 15 }}>
        <View style={[MyStyles.row, { marginTop: "auto", marginBottom: 0 }]}>
          <View style={{ width: "10%", minWidth: 80 }}>
            <Card
              style={[
                MyStyles.primaryColor,
                {
                  borderTopRightRadius: 10,
                  borderBottomRightRadius: 10,
                  marginVertical: 5,
                },
              ]}
            >
              <ImageBackground
                style={{}}
                imageStyle={{
                  borderTopRightRadius: 10,
                  borderBottomRightRadius: 10,
                }}
                source={require("../../assets/pattern.jpg")}
              >
                {/* <Card.Title title="E-Store" /> */}
                <View style={{ padding: 5 }}>
                  <Text style={{ fontSize: 15 }}>E-Store</Text>
                </View>
              </ImageBackground>
            </Card>
            <Card
              style={[
                MyStyles.primaryColor,
                {
                  borderTopRightRadius: 10,
                  borderBottomRightRadius: 10,
                  marginVertical: 5,
                },
              ]}
              onPress={() => setModal({ ...modal, upload: true })}
            >
              <ImageBackground
                style={{}}
                imageStyle={{
                  borderTopRightRadius: 10,
                  borderBottomRightRadius: 10,
                }}
                source={require("../../assets/pattern.jpg")}
              >
                {/* <Card.Title title="Upload" /> */}
                <View style={{ padding: 5 }}>
                  <Text style={{ fontSize: 15 }}>Upload</Text>
                </View>
              </ImageBackground>
            </Card>
          </View>
          <View style={{ width: "10%", minWidth: 80 }}>
            <Card
              style={[
                MyStyles.primaryColor,
                {
                  borderTopLeftRadius: 10,
                  borderBottomLeftRadius: 10,
                  marginVertical: 5,
                },
              ]}
              onPress={() => setModal({ ...modal, redeem: true })}
            >
              <ImageBackground
                style={{}}
                imageStyle={{
                  borderTopLeftRadius: 10,
                  borderBottomLeftRadius: 10,
                }}
                source={require("../../assets/pattern.jpg")}
              >
                {/* <Card.Title title="Redeem" /> */}
                <View style={{ padding: 5 }}>
                  <Text style={{ fontSize: 15, textAlign: "right" }}>Redeem</Text>
                </View>
              </ImageBackground>
            </Card>
            <Card
              style={[
                MyStyles.primaryColor,
                {
                  borderTopLeftRadius: 10,
                  borderBottomLeftRadius: 10,
                  marginVertical: 5,
                },
              ]}
              onPress={() => setModal({ ...modal, details: true })}
            >
              <ImageBackground
                style={{}}
                imageStyle={{
                  borderTopLeftRadius: 10,
                  borderBottomLeftRadius: 10,
                }}
                source={require("../../assets/pattern.jpg")}
              >
                {/* <Card.Title
                  title="Customer Details"
                  //titleStyle={{ fontSize: 15 }}
                /> */}
                <View style={{ padding: 5 }}>
                  <Text style={{ fontSize: 15, textAlign: "right" }}>C. Details</Text>
                </View>
              </ImageBackground>
            </Card>
          </View>
        </View>
        <View
          style={[
            MyStyles.row,
            {
              justifyContent: "space-between",
              margin: 0,
              paddingHorizontal: 40,
            },
          ]}
        >
          <Card
            style={[MyStyles.primaryColor, { width: "60%", borderRadius: 10 }]}
            onPress={() => setModal({ ...modal, checkIn: true })}
          >
            <ImageBackground
              style={{}}
              imageStyle={{ borderRadius: 10, opacity: 0.5 }}
              source={require("../../assets/pattern.jpg")}
            >
              {/* <Card.Title
                title={`Join ${branchName} Now`}
                subtitle="Accounts are free"
                right={() => <IconButton icon="chevron-right" size={30} />}
              /> */}
              <View style={{ paddingVertical: 15 }}>
                <Text
                  style={{ fontSize: 22, textAlign: "center" }}
                  numberOfLines={1}
                >{`Join ${branchName} Now`}</Text>
                <Text style={{ textAlign: "center" }}>Accounts are free</Text>
              </View>
            </ImageBackground>
          </Card>
          <Card
            style={[MyStyles.secondaryColor, { width: "35%", borderRadius: 10 }]}
            onPress={() => setModal({ ...modal, checkIn: true })}
          >
            <ImageBackground
              style={{}}
              imageStyle={{ borderRadius: 10, opacity: 0.5 }}
              source={require("../../assets/pattern.jpg")}
            >
              {/* <Card.Title
                title="Check In"
                subtitle="for Rewards"
                right={() => <IconButton icon="chevron-right" size={30} />}
              /> */}
              <View style={{ paddingVertical: 15 }}>
                <Text style={{ fontSize: 22, textAlign: "center" }} numberOfLines={1}>
                  Check In
                </Text>
                <Text style={{ textAlign: "center" }}>for Rewards</Text>
              </View>
            </ImageBackground>
          </Card>
        </View>
      </View>

      {/*------------ Details Modal ------------------- */}

      <CustomModal
        visible={modal.details}
        content={
          !details ? (
            <View>
              <TextInput
                mode="flat"
                style={{ backgroundColor: "rgba(0,0,0,0)" }}
                label="Enter Mobile No."
                placeholder="eg:9876543210"
                value={modal.mobile}
                onChangeText={(text) => setModal({ ...modal, mobile: text })}
                maxLength={10}
                keyboardType="number-pad"
                left={
                  <TextInput.Icon
                    theme={{ colors: { text: "#aaaaaa" } }}
                    color="green"
                    size={25}
                    style={{ marginBottom: 0 }}
                    name="phone"
                  />
                }
              //  left={<TextInput.Affix text="+91-" />}
              />
              {recentVistors.map((item, index) => (
                <List.Item
                  onPress={() => {
                    setModal({ ...modal, mobile: item.mobile });
                  }}
                  key={index}
                  title={"+91 " + item.mobile}
                  left={(props) => <List.Icon {...props} icon="history" />}
                />
              ))}
              <View style={[MyStyles.row, { marginTop: 10 }]}>
                <Button
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => setModal({ ...modal, details: false })}
                >
                  Close
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    postRequest(
                      "customervisit/getCustomerDetails",
                      {
                        mobile: modal.mobile,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setDetails(resp?.data);
                      }
                    });
                  }}
                >
                  Continue
                </Button>
              </View>
            </View>
          ) : (
            <View style={{ height: "100%" }}>
              <ScrollView>
                <View style={MyStyles.wrapper}>
                  <View style={MyStyles.row}>
                    <View style={{ flex: 1 }}>
                      <Text>Name</Text>
                      <Text style={MyStyles.text}>{details?.full_name}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Mobile</Text>
                      <Text style={MyStyles.text}>{details?.mobile}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Date of Birth</Text>
                      <Text style={MyStyles.text}>{moment(details?.dob).format("DD/MM/YYYY")}</Text>
                    </View>
                  </View>
                  <View style={MyStyles.row}>
                    <View style={{ flex: 1 }}>
                      <Text>Date of Aniversary</Text>
                      <Text style={MyStyles.text}>
                        {moment(details?.doa).format("DD/MM/YYYY") ? details.doa : "N/A"}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Profession</Text>
                      <Text style={MyStyles.text}>{details?.profession}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Address</Text>
                      <Text style={MyStyles.text}>{details?.address}</Text>
                    </View>
                  </View>
                  <View style={MyStyles.row}>
                    <View style={{ flex: 1 }}>
                      <Text>Branch Name</Text>
                      <Text style={MyStyles.text}>{details?.branch_name}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Staff Name</Text>
                      <Text style={MyStyles.text}>
                        {details.staff_name ? details.staff_name : "N/A"}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Ref Name</Text>
                      <Text style={MyStyles.text}>
                        {details.ref_name ? details.ref_name : "N/A"}
                      </Text>
                    </View>
                  </View>
                  <View style={MyStyles.row}>
                    <View style={{ flex: 1 }}>
                      <Text>Category Name</Text>
                      <Text style={MyStyles.text}>{details?.category_name}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Total Visit</Text>
                      <Text style={MyStyles.text}>
                        <Text style={MyStyles.text}>{details?.total_visit}</Text>
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text>Last Visit</Text>
                      <Text style={MyStyles.text}>{details?.last_visit}</Text>
                    </View>
                  </View>
                </View>
              </ScrollView>
              <View style={[MyStyles.row, { justifyContent: "flex-end" }]}>
                <Button
                  style={{ marginRight: "auto" }}
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => {
                    setModal({ ...modal, details: false });
                    setDetails(null);
                  }}
                >
                  Close
                </Button>
                <Button
                  style={{ marginHorizontal: 5 }}
                  mode="contained"
                  color="#E1C16E"
                  uppercase={false}
                  compact
                  onPress={() => {
                    postRequest(
                      "customervisit/getCustomerHistory",
                      {
                        customer_id: details?.customer_id,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setHistory(resp?.data);
                        setModal({ ...modal, details: false, history: true });
                      }
                    });
                  }}
                >
                  History
                </Button>
                <Button
                  style={{ marginHorizontal: 5 }}
                  mode="contained"
                  color="#87CEEB"
                  uppercase={false}
                  compact
                  onPress={() => {
                    postRequest(
                      "customervisit/getCustomerUploadHistory",
                      {
                        customer_id: details?.customer_id,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setDesign(resp?.data);
                        setModal({ ...modal, details: false, design: true });
                      }
                    });
                    postRequest(
                      "customervisit/getCustomerWishlistHistory",
                      {
                        customer_id: details?.customer_id,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setWishlist(resp?.data);
                      }
                    });
                    postRequest(
                      "customervisit/getCustomerExhibitionHistory",
                      {
                        customer_id: details?.customer_id,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setExhibition(resp?.data);
                      }
                    });
                  }}
                >
                  Design
                </Button>
              </View>
            </View>
          )
        }
      />

      {/*------------ History Modal ------------------- */}

      <CustomModal
        visible={modal.history}
        content={
          <View>
            <DataTable style={{ height: "100%" }}>
              <DataTable.Header>
                <DataTable.Title
                  style={{ flex: 2, justifyContent: "center" }}
                  theme={{ colors: { text: "#0818A8" } }}
                >
                  Datetime
                </DataTable.Title>
                <DataTable.Title
                  style={{ flex: 1, justifyContent: "center" }}
                  theme={{ colors: { text: "#0818A8" } }}
                >
                  Type
                </DataTable.Title>
                <DataTable.Title
                  style={{ flex: 1, justifyContent: "center" }}
                  theme={{ colors: { text: "#0818A8" } }}
                >
                  Details
                </DataTable.Title>
                <DataTable.Title
                  style={{ flex: 1, justifyContent: "center" }}
                  theme={{ colors: { text: "#0818A8" } }}
                >
                  Status
                </DataTable.Title>
              </DataTable.Header>
              <FlatList
                data={history}
                renderItem={({ item, index }) => (
                  <DataTable.Row>
                    <DataTable.Cell style={{ flex: 2, justifyContent: "center" }}>
                      {item.date}
                    </DataTable.Cell>
                    <DataTable.Cell style={{ flex: 1, justifyContent: "center" }}>
                      {item.type}
                    </DataTable.Cell>
                    <DataTable.Cell style={{ flex: 1, justifyContent: "center" }}>
                      {item.details}
                    </DataTable.Cell>
                    <DataTable.Cell style={{ flex: 1, justifyContent: "center" }}>
                      {item.action}
                    </DataTable.Cell>
                  </DataTable.Row>
                )}
                keyExtractor={(item, index) => index.toString()}
              />
              <View style={[MyStyles.row, { marginTop: 10 }]}>
                <Button
                  style={{ marginRight: "auto" }}
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => {
                    setModal({ ...modal, history: false });
                    setDetails(null);
                  }}
                >
                  Close
                </Button>

                <Button
                  style={{ marginHorizontal: 5 }}
                  mode="contained"
                  color="#87CEEB"
                  uppercase={false}
                  compact
                  onPress={() => {
                    setModal({ ...modal, history: false, details: true });
                  }}
                >
                  Back
                </Button>
              </View>
            </DataTable>
          </View>
        }
      />

      {/*------------ Design Modal ------------------- */}

      <CustomModal
        visible={modal.design}
        content={
          <View style={{ height: "100%" }}>
            <View
              style={[
                MyStyles.row,
                {
                  justifyContent: "flex-start",
                  paddingTop: 5,
                },
              ]}
            >
              <Button
                mode="outlined"
                uppercase={false}
                compact
                color={tabs === 1 ? "blue" : "#AAA"}
                style={{
                  borderWidth: 1,
                  borderBottomWidth: 0,
                  marginHorizontal: 5,
                }}
                onPress={() => setTabs(1)}
              >
                My Designs
              </Button>
              <Button
                mode="outlined"
                uppercase={false}
                compact
                color={tabs === 2 ? "blue" : "#AAA"}
                style={{
                  borderWidth: 1,
                  borderBottomWidth: 0,
                  marginHorizontal: 5,
                }}
                onPress={() => setTabs(2)}
              >
                Wishlisht
              </Button>
              <Button
                mode="outlined"
                uppercase={false}
                compact
                color={tabs === 3 ? "blue" : "#AAA"}
                style={{
                  borderWidth: 1,
                  borderBottomWidth: 0,
                  marginHorizontal: 5,
                }}
                onPress={() => setTabs(3)}
              >
                Exhibition
              </Button>
            </View>

            {/*------------ My Design Tab ------------------- */}

            {tabs === 1 && (

              <Swiper showsButtons showsPagination={false}>
                {design.map((item, index) => {
                  return (
                    <View style={[MyStyles.row, { flex: 1 }]} key={index}>
                      <Image
                        source={{ uri: item.url + item.image_path }}
                        style={[
                          {
                            resizeMode: "contain",
                            borderRadius: 5,
                            height: "100%",
                            flex: 2,
                          },
                        ]}
                      />
                      <View style={{ flex: 1, marginLeft: 10 }}>
                        <ScrollView>
                          <View style={MyStyles.wrapper}>
                            <Text>SKU</Text>
                            <Text style={MyStyles.text}>{item.sku ? item.sku : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Remarks</Text>
                            <Text style={MyStyles.text}>{item.remarks ? item.remarks : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Staff</Text>
                            <Text style={MyStyles.text}>
                              {item.staff_name ? item.staff_name : "N/A"}
                            </Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Date</Text>
                            <Text style={MyStyles.text}>{item.date ? item.date : "N/A"}</Text>
                          </View>
                        </ScrollView>
                      </View>
                    </View>
                  );
                })}
              </Swiper>

            )}

            {/*------------ Wishlist Tab ------------------- */}

            {tabs === 2 && (
              <Swiper style={{ height: "100%" }} showsButtons showsPagination={false}>
                {wishlist.map((item, index) => {
                  return (
                    <View style={[MyStyles.row, { flex: 1 }]} key={index}>
                      <Image
                        source={{ uri: item.url + item.image_path }}
                        style={[
                          {
                            resizeMode: "contain",
                            borderRadius: 5,
                            height: "100%",
                            flex: 2,
                          },
                        ]}
                      />
                      <View style={{ flex: 1, marginLeft: 10 }}>
                        <ScrollView>
                          <View style={MyStyles.wrapper}>
                            <Text>Product Name</Text>
                            <Text style={MyStyles.text}>
                              {item.product_name ? item.product_name : "N/A"}
                            </Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>SKU</Text>
                            <Text style={MyStyles.text}>{item.sku ? item.sku : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Remarks</Text>
                            <Text style={MyStyles.text}>{item.remarks ? item.remarks : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Date</Text>
                            <Text style={MyStyles.text}>{item.date ? item.date : "N/A"}</Text>
                          </View>
                        </ScrollView>
                      </View>
                    </View>
                  );
                })}
              </Swiper>
            )}

            {/*------------ Exhibition Tab ------------------- */}

            {tabs === 3 && (
              <Swiper style={{ height: "100%" }} showsButtons showsPagination={false}>
                {exhibition.map((item, index) => {
                  return (
                    <View style={[MyStyles.row, { flex: 1 }]} key={index}>
                      <Image
                        source={{ uri: item.url + item.image_path }}
                        style={[
                          {
                            resizeMode: "contain",
                            borderRadius: 5,
                            height: "100%",
                            flex: 2,
                          },
                        ]}
                      />
                      <View style={{ flex: 1, marginLeft: 10 }}>
                        <ScrollView>
                          <View style={MyStyles.wrapper}>
                            <Text>Product Name</Text>
                            <Text style={MyStyles.text}>
                              {item.product_name ? item.product_name : "N/A"}
                            </Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>SKU</Text>
                            <Text style={MyStyles.text}>{item.sku ? item.sku : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Remarks</Text>
                            <Text style={MyStyles.text}>{item.remarks ? item.remarks : "N/A"}</Text>
                          </View>
                          <View style={MyStyles.wrapper}>
                            <Text>Date</Text>
                            <Text style={MyStyles.text}>{item.date ? item.date : "N/A"}</Text>
                          </View>
                        </ScrollView>
                      </View>
                    </View>
                  );
                })}
              </Swiper>
            )}

            <View style={[MyStyles.row, { marginTop: 10 }]}>
              <Button
                style={{ marginRight: "auto" }}
                mode="contained"
                color="#DC143C"
                uppercase={false}
                compact
                onPress={() => {
                  setModal({ ...modal, design: false });
                  setDetails(null);
                }}
              >
                Close
              </Button>

              <Button
                style={{ marginHorizontal: 5 }}
                mode="contained"
                color="#87CEEB"
                uppercase={false}
                compact
                onPress={() => {
                  setModal({ ...modal, design: false, details: true });
                }}
              >
                Back
              </Button>
            </View>
          </View>
        }
      />

      {/*------------ Redeem Modal ------------------- */}

      <CustomModal
        visible={modal.redeem}
        content={
          !redeem ? (
            <View>
              <TextInput
                mode="flat"
                style={{ backgroundColor: "rgba(0,0,0,0)" }}
                label="Enter Mobile No."
                placeholder="eg:9876543210"
                value={modal.mobile}
                onChangeText={(text) => setModal({ ...modal, mobile: text })}
                maxLength={10}
                keyboardType="number-pad"
                left={
                  <TextInput.Icon
                    theme={{ colors: { text: "#aaaaaa" } }}
                    color="green"
                    size={25}
                    style={{ marginBottom: 0 }}
                    name="phone"
                  />
                }
              //  left={<TextInput.Affix text="+91-" />}
              />
              {recentVistors.map((item, index) => (
                <List.Item
                  onPress={() => {
                    setModal({ ...modal, mobile: item.mobile });
                  }}

                  key={index}
                  title={"+91 " + item.mobile}
                  left={(props) => <List.Icon {...props} icon="history" />}
                />
              ))}
              <View style={[MyStyles.row, { marginTop: 10 }]}>
                <Button
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => setModal({ ...modal, redeem: false })}
                >
                  Close
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    console.log("modal.mobile", modal.mobile);
                    postRequest(
                      "customervisit/getCustomerVisit",
                      { mobile: modal.mobile },
                      token
                    ).then((resp) => {
                      if (resp?.status === 200) {
                        const customerData = resp.data;
                        console.log("VoucherList", customerData);
                        setVoucherList(customerData);
                        setCustomerId(customerData[0].customer_id);
                        console.log("customerId", customerData[0].customer_id);

                        // 1️⃣ Fetch customer points
                        postRequest(
                          "customervisit/getCustomerPointList",
                          {
                            customer_id: customerData[0].customer_id,
                            branch_id: branchId,
                          },
                          token
                        ).then((pointResp) => {
                          if (pointResp?.status === 200) {
                            console.log("Active points:", pointResp.data);
                            setPoints(pointResp.data);

                            // 2️⃣ Fetch expired points
                            postRequest(
                              "customervisit/getCustomerExpirePointList",
                              {
                                customer_id: customerData[0].customer_id,
                                branch_id: branchId,
                              },
                              token
                            ).then((expirePointResp) => {
                              if (expirePointResp?.status === 200) {
                                console.log("Expired Points:", expirePointResp.data);
                                setExpiredPoints?.(expirePointResp.data); // only if this state exists

                                // 3️⃣ Fetch customer redeem points
                                postRequest(
                                  "customervisit/getCustomerRedeemPointList",
                                  {
                                    customer_id: customerData[0].customer_id,
                                    branch_id: branchId,
                                  },
                                  token
                                ).then((redeemPointResp) => {
                                  if (redeemPointResp?.status === 200) {
                                    console.log("Redeemed Points:", redeemPointResp.data);
                                    setRedeemPoints(redeemPointResp.data);

                                    // 4️⃣ Fetch customer vouchers
                                    postRequest(
                                      "customervisit/getCustomerVoucherList",
                                      {
                                        customer_id: customerData[0].customer_id,
                                        branch_id: branchId,
                                      },
                                      token
                                    ).then((voucherResp) => {
                                      if (voucherResp?.status === 200) {
                                        console.log("Redeem List:-----", voucherResp.data);
                                        setRedeem(voucherResp.data);
                                        setModal({ ...modal, redeem: true });
                                      }
                                    });
                                  }
                                });
                              }
                            });
                          }
                        });
                      }
                    });
                  }}


                >
                  Continue
                </Button>
              </View>
            </View>
          ) : (
            <RedeemModal visible={modal.redeem} onClose={() => { setModal({ ...modal, redeem: false }); setRedeem(null); setPoints(null); }} points={points} redeem={redeem} expiredPoints={expiredPoints} redeemPoints={redeemPoints} voucherList={voucherList} token={token} staffList={staffList} />
          )
        }
      />

      {/*------------ Join-Now Modal ------------------- */}

      <CustomModal
        visible={modal.join}
        content={
          join.step1 ? (
            <View>
              <View style={MyStyles.wrapper}>
                <View style={MyStyles.row}>
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Name"
                    error={!join.full_name}
                    value={join.full_name}
                    onChangeText={(text) => setJoin({ ...join, full_name: text })}
                  />
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Mobile"
                    disabled
                    maxLength={10}
                    keyboardType="number-pad"
                    value={join.mobile}
                  />
                  <DropDown
                    data={[
                      { label: "Male", value: "Male" },
                      { label: "Female", value: "Female" },
                      { label: "Others", value: "Others" },
                    ]}
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    placeholder="Gender"
                    value={join.gender}
                    onChange={(val) => setJoin({ ...join, gender: val })}
                  />
                </View>
                <View style={MyStyles.row}>
                  <DatePicker
                    label="Date Of Birth"
                    inputStyles={{ backgroundColor: "rgba(0,0,0,0)", flex: 1, marginRight: 20 }}
                    value={join.dob}
                    onValueChange={(val) => setJoin({ ...join, dob: val })}
                  />
                  <DatePicker
                    label="Date Of Aniversary"
                    inputStyles={{ backgroundColor: "rgba(0,0,0,0)", flex: 1, marginLeft: 20 }}
                    value={join.doa}
                    onValueChange={(val) => setJoin({ ...join, doa: val })}
                  />
                </View>
                <TextInput
                  mode="flat"
                  style={{ backgroundColor: "rgba(0,0,0,0)" }}
                  label="Address"
                  value={join.address}
                  onChangeText={(text) => setJoin({ ...join, address: text })}
                />
              </View>
              <View style={MyStyles.row}>
                <Button
                  mode="contained"
                  color="red"
                  uppercase={false}
                  compact
                  onPress={() => {
                    setModal({ ...modal, join: false });
                    setJoin({});
                  }}
                >
                  Close
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    if (join.full_name != "") {
                      setJoin({ ...join, step1: false });
                    }
                  }}
                >
                  Continue
                </Button>
              </View>
            </View>
          ) : (
            <View>
              <View style={MyStyles.wrapper}>
                <View style={MyStyles.row}>
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Name"
                    disabled
                    value={join.full_name}
                  />
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Mobile"
                    disabled
                    value={join.mobile}
                  />
                </View>
                <View style={MyStyles.row}>
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Refrence Mobile"
                    maxLength={10}
                    keyboardType="number-pad"
                    onChangeText={(text) => {
                      if (text.length == 10) {
                        postRequest(
                          "customervisit/getCustomerVisit",
                          {
                            mobile: text,
                          },
                          token
                        ).then((resp) => {
                          if (resp?.status == 200) {
                            console.log(resp.data[0].customer_id);
                            setJoin({
                              ...join,
                              ref_id: resp.data[0].customer_id,
                              ref_name: resp.data[0].full_name,
                            });
                          }
                        });
                      }
                    }}
                  />
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    label="Refrence Name"
                    disabled
                    value={join.ref_name}
                    onChangeText={(text) => setJoin({ ...join, ref_name: text })}
                  />
                  <DropDown
                    value={join.category_id}
                    ext_lbl="category_name"
                    ext_val="category_id"
                    data={categoryList}
                    placeholder="Category"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    onChange={(val) => setJoin({ ...join, category_id: val })}
                  />
                  <DropDown
                    value={join.staff_id}
                    ext_lbl="name"
                    ext_val="staff_id"
                    data={staffList}
                    placeholder="Staff"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    onChange={(val) => setJoin({ ...join, staff_id: val })}
                  />
                </View>
                <View style={MyStyles.row}>
                  <DropDown
                    value={join.area_id}
                    ext_lbl="area_name"
                    ext_val="area_id"
                    data={areaList}
                    placeholder="Area"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 1 }}
                    onChange={(val) => setJoin({ ...join, area_id: val })}
                  />
                  <IconButton
                    icon="plus"
                    size={20}
                    style={{ backgroundColor: "#ffba3c" }}
                    onPress={() => setModal({ ...modal, area: true })}
                  />
                  <TextInput
                    mode="flat"
                    style={{ backgroundColor: "rgba(0,0,0,0)", flex: 2 }}
                    label="Profession"
                    value={join.profession}
                    onChangeText={(text) => setJoin({ ...join, profession: text })}
                  />
                </View>
              </View>
              <View style={MyStyles.row}>
                <Button
                  mode="contained"
                  color="red"
                  compact
                  uppercase={false}
                  style={{ marginRight: "auto" }}
                  onPress={() => {
                    setModal({ ...modal, join: false });
                    setJoin({});
                  }}
                >
                  Close
                </Button>

                <Button
                  mode="contained"
                  color="#87CEEB"
                  compact
                  uppercase={false}
                  style={{ marginHorizontal: 10 }}
                  onPress={() => setJoin({ ...join, step1: true })}
                >
                  Back
                </Button>

                <Button
                  mode="contained"
                  color="#ffba3c"
                  compact
                  uppercase={false}
                  onPress={() => {
                    postRequest("customervisit/insertNewCustomerVisit", join, token).then(
                      (resp) => {
                        console.log(resp);
                        if (resp?.status == 200) {
                          setModal({ ...modal, join: false });
                          setJoin({});
                        }
                      }
                    );
                  }}
                >
                  Continue
                </Button>
              </View>
            </View>
          )
        }
      />

      {/*------------ Area Modal ------------------- */}

      <CustomModal
        visible={modal.area}
        content={
          <View>
            <TextInput
              mode="flat"
              style={{ backgroundColor: "rgba(0,0,0,0)" }}
              label="Area Name"
              value={modal.area_name}
              onChangeText={(text) => {
                setModal({ ...modal, area_name: text });
              }}
            />
            <View style={MyStyles.row}>
              <Button
                mode="contained"
                color="red"
                uppercase={false}
                compact
                onPress={() => setModal({ ...modal, area: false, area_name: "" })}
              >
                Close
              </Button>
              <Button
                mode="contained"
                color="#ffba3c"
                uppercase={false}
                compact
                onPress={() => {
                  postRequest(
                    "customervisit/insertArea",
                    {
                      area_id: "0",
                      area_name: modal.area_name,
                      branch_id: branchId,
                    },
                    token
                  ).then((resp) => {
                    if (resp?.status == 200) {
                      setModal({ ...modal, area: false });
                      postRequest("customervisit/AreaList", {}, token).then((resp) => {
                        if (resp?.status == 200) {
                          setAreaList(resp.data);
                        }
                      });
                    }
                  });
                }}
              >
                Save
              </Button>
            </View>
          </View>
        }
      />

      {/*------------ CheckIn Modal ------------------- */}

      {!checkIn ? (
        <CustomModal
          visible={modal.checkIn}
          content={
            <View>
              <TextInput
                mode="flat"
                style={{ backgroundColor: "rgba(0,0,0,0)" }}
                label="Enter Mobile No."
                placeholder="eg:9876543210"
                value={modal.mobile}
                onChangeText={(text) => setModal({ ...modal, mobile: text })}
                maxLength={10}
                keyboardType="number-pad"
                left={
                  <TextInput.Icon
                    theme={{ colors: { text: "#aaaaaa" } }}
                    color="green"
                    size={25}
                    style={{ marginBottom: 0 }}
                    name="phone"
                  />
                }
              //  left={<TextInput.Affix text="+91-" />}
              />
              {recentVistors.map((item, index) => (
                <List.Item
                  onPress={() => {
                    setModal({ ...modal, mobile: item.mobile });
                  }}
                  key={index}
                  title={"+91 " + item.mobile}
                  left={(props) => <List.Icon {...props} icon="history" />}
                />
              ))}
              <View style={[MyStyles.row, { marginTop: 10 }]}>
                <Button
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => setModal({ ...modal, checkIn: false })}
                >
                  Close
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    postRequest(
                      "customervisit/getCustomerVisit",
                      {
                        mobile: modal.mobile,
                      },
                      token
                    ).then((resp) => {
                      //console.log(resp);
                      if (resp?.status == 200) {
                        postRequest(
                          "customervisit/insertCustomerVisit",
                          {
                            customer_id: resp.data[0].customer_id,
                            tran_id: "0",
                          },
                          token
                        ).then((resp) => {
                          if (resp?.status == 200) {
                            setCheckIn(resp.data[0]);
                            setTimeout(() => {
                              setModal({ ...modal, checkIn: false });
                              setCheckIn(null);
                            }, 8000);
                          }
                        });
                      }
                      if (resp?.status == 500) {
                        setJoin({ ...join, mobile: modal.mobile });
                        setModal({ ...modal, join: true, checkIn: false });
                      }
                    });
                  }}
                >
                  Continue
                </Button>
              </View>
            </View>
          }
        />
      ) : (
        <Portal>
          <ImageBackground style={{ flex: 1 }} source={require("../../assets/thank.jpg")}>
            <Modal
              visible={modal.checkIn}
              dismissable={false}
              contentContainerStyle={{
                flex: 1,
                top: 0,
              }}
            >
              <View style={{ flex: 1 }}></View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 40,
                    color: "#fff",
                    textAlign: "center",
                    // fontFamily: "ElMessiri-bold",
                  }}
                >
                  Thank You
                </Text>
              </View>
              <View style={[MyStyles.row,
              {
                justifyContent: "space-between",
                margin: 0,
                paddingHorizontal: 40,
              },]}>
                <Card
                  style={[MyStyles.primaryColor, { width: "60%", borderRadius: 10 }]}
                  onPress={() => setModal({ ...modal, checkIn: true })}
                >
                  <ImageBackground
                    style={{}}
                    imageStyle={{ borderRadius: 10, opacity: 0.5 }}
                    source={require("../../assets/pattern.jpg")}
                  >
                    {/* <Card.Title
                title={`Join ${branchName} Now`}
                subtitle="Accounts are free"
                right={() => <IconButton icon="chevron-right" size={30} />}
              /> */}
                    <View style={{ paddingVertical: 15 }}>
                      <Text
                        style={{ fontSize: 22, textAlign: "center" }}
                        numberOfLines={1}
                      >{checkIn.customer_name}</Text>
                    </View>
                  </ImageBackground>
                </Card>
                <Card
                  style={[MyStyles.secondaryColor, { width: "35%", borderRadius: 10 }]}
                  onPress={() => setModal({ ...modal, checkIn: true })}
                >
                  <ImageBackground
                    style={{}}
                    imageStyle={{ borderRadius: 10, opacity: 0.5 }}
                    source={require("../../assets/pattern.jpg")}
                  >
                    {/* <Card.Title
                title="Check In"
                subtitle="for Rewards"
                right={() => <IconButton icon="chevron-right" size={30} />}
              /> */}

                    <View style={{ paddingVertical: 15 }}>
                      <Text style={{ fontSize: 22, textAlign: "center" }} numberOfLines={1}>
                        {checkIn.total_visit}
                      </Text>

                    </View>
                  </ImageBackground>
                </Card>
                {/* <Card style={[MyStyles.primaryColor, { width: "60%", borderRadius: 10 }]}>
                  <ImageBackground
                    style={{ flex: 1 }}
                    imageStyle={{ borderRadius: 10, opacity: 0.5 }}
                    source={require("../../assets/pattern.jpg")}
                  >
                    <Card.Title
                      style={{ flex: 1 }}
                      title={checkIn.customer_name}
                      titleStyle={{
                        fontSize: 25,
                        // fontFamily: "ElMessiri-bold",
                      }}
                    />
                  </ImageBackground>
                </Card> */}
                {/* <Card style={[MyStyles.primaryColor, { width: "40%", borderRadius: 10 }]}>
                  <ImageBackground
                    style={{ flex: 1 }}
                    imageStyle={{ borderRadius: 10, opacity: 0.5 }}
                    source={require("../../assets/pattern.jpg")}
                  >
                    <Card.Title
                      style={{ flex: 1 }}
                      title={checkIn.total_visit}
                      titleStyle={{
                        fontSize: 25,
                        // fontFamily: "ElMessiri-bold",
                      }}
                    />
                  </ImageBackground>
                </Card> */}
              </View>
            </Modal>
          </ImageBackground>
        </Portal>
      )}

      {/*------------ Upload Modal ------------------- */}

      <CustomModal
        visible={modal.upload}
        content={
          !upload ? (
            <View>
              <TextInput
                mode="flat"
                style={{ backgroundColor: "rgba(0,0,0,0)" }}
                label="Enter Mobile No."
                placeholder="eg:9876543210"
                value={modal.mobile}
                onChangeText={(text) => setModal({ ...modal, mobile: text })}
                maxLength={10}
                keyboardType="number-pad"
                left={
                  <TextInput.Icon
                    theme={{ colors: { text: "#aaaaaa" } }}
                    color="green"
                    size={25}
                    style={{ marginBottom: 0 }}
                    name="phone"
                  />
                }
              //  left={<TextInput.Affix text="+91-" />}
              />
              {recentVistors.map((item, index) => (
                <List.Item
                  onPress={() => {
                    setModal({ ...modal, mobile: item.mobile });
                  }}
                  key={index}
                  title={"+91 " + item.mobile}
                  left={(props) => <List.Icon {...props} icon="history" />}
                />
              ))}
              <View style={[MyStyles.row, { marginTop: 10 }]}>
                <Button
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => setModal({ ...modal, upload: false })}
                >
                  Close
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    postRequest(
                      "customervisit/getCustomerVisit",
                      {
                        mobile: modal.mobile,
                      },
                      token
                    ).then((resp) => {
                      if (resp?.status == 200) {
                        setUpload({
                          tran_id: "0",
                          branch_id: branchId,
                          customer_id: resp.data[0].customer_id,
                          full_name: resp.data[0].full_name,
                          mobile: resp.data[0].mobile,
                          remarks: "",
                          sku: "",
                          staff_id: "",
                          image_path: "",
                          image_data: "",
                          uri: require("../../assets/upload.png"),
                        });
                        console.log(resp.data);
                      }
                    });
                  }}
                >
                  Continue
                </Button>
              </View>
            </View>
          ) : (
            <View style={{ height: "100%" }}>
              <ScrollView>
                <View style={[MyStyles.row, { fontSize: 12 }]}>
                  <View style={{ flex: 1, paddingHorizontal: 10 }}>
                    <View style={MyStyles.row}>
                      <TextInput
                        mode="flat"
                        style={{ backgroundColor: "rgba(0,0,0,0)" }}
                        label="Name"
                        value={upload?.full_name}
                        disabled
                      />
                      <TextInput
                        mode="flat"
                        style={{ backgroundColor: "rgba(0,0,0,0)" }}
                        label="Mobile No."
                        value={upload?.mobile}
                        disabled
                      />

                      <DropDown
                        value={upload?.staff_id}
                        ext_lbl="name"
                        ext_val="staff_id"
                        data={staffList}
                        placeholder="Staff"
                        onChange={(val) => setUpload({ ...upload, staff_id: val })}
                        style={{
                          borderColor: '#ccc',
                          borderWidth: 1,
                          borderRadius: 6,
                          paddingHorizontal: 2,
                          fontSize: 12,
                          marginBottom: 2,
                          minWidth: 150,
                          height: 50,
                        }}
                      />
                    </View>


                      <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#000', marginVertical: 6 }}>Category</Text>
                      <View style={[MyStyles.checkboxContainer, { fontSize: 12 }]}>
                        <Pressable onPress={() => toggleCategory('scooter')} style={MyStyles.checkboxRow}>
                          <View style={[MyStyles.checkbox, category.scooter && MyStyles.checked]}>
                            {category.scooter && <Text style={MyStyles.tick}>✓</Text>}
                          </View>
                          <Text style={[MyStyles.checkboxLabel, { fontSize: 12 }]}>SCOOTER</Text>
                        </Pressable>

                        <Pressable onPress={() => toggleCategory('motorcycle')} style={MyStyles.checkboxRow}>
                          <View style={[MyStyles.checkbox, category.motorcycle && MyStyles.checked]}>
                            {category.motorcycle && <Text style={MyStyles.tick}>✓</Text>}
                          </View>
                          <Text style={[MyStyles.checkboxLabel, { fontSize: 12 }]}>MOTORCYCLE</Text>
                        </Pressable>

                        <Pressable onPress={() => toggleCategory('bike')} style={MyStyles.checkboxRow}>
                          <View style={[MyStyles.checkbox, category.bike && MyStyles.checked]}>
                            {category.bike && <Text style={MyStyles.tick}>✓</Text>}
                          </View>
                          <Text style={[MyStyles.checkboxLabel, { fontSize: 12 }]}>BIKE</Text>
                        </Pressable>
                      </View>


                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#000', marginVertical: 2, marginBottom: 6 }}>Interest</Text>
                    <View style={[MyStyles.radioContainer, { flexDirection: 'row', alignItems: 'center', gap: 16 }]}>
                      {['yes', 'followup', 'requirement'].map((item, idx, arr) => (
                        <Pressable
                          key={item}
                          onPress={() => setInterest(item)}
                          style={[MyStyles.radioRow, idx !== arr.length - 1 ? { marginRight: 40 } : null]}
                        >
                          <View style={interest === item ? MyStyles.radioSelected : MyStyles.radio} />
                          <Text style={[MyStyles.radioLabel, { fontSize: 14 }]}>
                            {item === 'yes' ? 'Yes' : item === 'followup' ? 'Follow Up' : 'Requirement'}
                          </Text>
                        </Pressable>
                      ))}
                    </View>


                  </View>
                </View>
              </ScrollView>
              <View style={[MyStyles.row, { margin: 10 }]}>
                <Button
                  mode="contained"
                  color="#DC143C"
                  uppercase={false}
                  compact
                  onPress={() => {
                    setModal({ ...modal, upload: false });
                    setUpload(null);
                  }}
                >
                  CANCEL
                </Button>
                <Button
                  mode="contained"
                  color="#ffba3c"
                  uppercase={false}
                  compact
                  onPress={() => {
                    if(payloadData.length > 0){
                    setModal({ ...modal, uploadNext: true, checkIn: false, upload: false });
                    }else{
                      alert("Please select at least one category");
                    }
                  }}
                >
                  NEXT
                </Button>
              </View>
            </View>
          )
        }
      />

      {/*------------ Upload Next Modal ------------------- */}
      <CustomModal
        visible={modal.uploadNext}
        content={
          <View style={{ height: "100%" }}>
            <ScrollView>
              <View style={[MyStyles.row, { justifyContent: "space-around", flexWrap: 'wrap' }]}>
  {payloadData.map((payload, index) => (
    <View key={index} style={{ flex: 0.30, marginBottom: 20 }}>
      <Text
        style={{
          backgroundColor: "#eee",
          textAlign: "center",
          paddingVertical: 6,
          fontWeight: "bold",
          color: "#999",
          borderTopLeftRadius: 6,
          borderTopRightRadius: 6,
          marginBottom: 6,
        }}
      >
        Category{'\n'}
        <Text style={{ fontSize: 18, color: "#333" }}>
          {payload.category_id === "2180"
            ? "SCOOTER"
            : payload.category_id === "2181"
            ? "MOTORCYCLE"
            : "BIKE"}
        </Text>
      </Text>

      {/* Choose Files Button */}
      <Button
      mode="contained"
      compact
      style={{ flex: 1, marginBottom: 10 }}
      buttonColor="#1abc9c"
      textColor="#fff"
      onPress={() => {
        ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          quality: 1,
        }).then((result) => {
          console.log("ImagePicker result:", result);
      
          if (!result.cancelled) {
            const image = result.uri;
      
            const formData = new FormData();
            formData.append("files", {
              uri: image,
              name: "photo.jpg",
              type: "image/jpeg",
            });
      
            uploadImage("customervisit/UploadCustomerImage", formData, token)
              .then((response) => {
                setPayloadData((prev) => {
                  const updated = [...prev];

                  updated[index] = {
                    ...updated[index],
                    image_path: {
                      ...updated[index]?.image_path,
                      choose: image,
                    },
                  };
                  return updated;
                })
              })
              .catch((error) => {
                console.error("Upload error:", error);
              });
          }
        }).catch((err) => {
          console.error("ImagePicker error:", err);
        });
      }}
    >
      Choose Files
    </Button>

    {/* Dynamic Image Below */}
    <Image
  source={{
    uri:  `${payloadData[index]?.image_path?.choose
      ? payloadData[index].image_path.choose
      : payloadData[index]?.image_path?.url}`
  }}
  style={{
    height: 130,
    width: "100%",
    marginVertical: 10,
    resizeMode: "contain",
  }}
/>

{/* Add Images Button */}
<View style={MyStyles.row}>
<Button
      mode="contained"
      compact
      style={{ color: "white" }}
      onPress={pickImage}
      color="#1abc9c"
    >
      <Text style={{color: "white"}}>ADD IMAGES</Text>
    </Button>
    <View style={{marginLeft: 10}}>
      <Button
    icon="upload" 
    style={{ backgroundColor: "#3699fe", width: 50}}
    textColor="#fff"
    onPress={handleUpload}
    color="white"
    />
    </View>
</View>
<ScrollView
  horizontal
  showsHorizontalScrollIndicator={false}
  contentContainerStyle={{ paddingVertical: 10, paddingHorizontal: 5 }}
>
  {image.map((uri, idx) => (
    <View
      key={idx}
      style={{
        marginRight: 10,
        borderRadius: 8,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: "#ccc",
      }}
    >
      <Image
        source={{ uri }}
        style={{
          height: 130,
          width: 130,
          resizeMode: "cover",
        }}
      />
    </View>
  ))}
</ScrollView>

      {/* SKU Input */}
      <TextInput
        mode="outlined"
        label="SKU"
        style={{ marginBottom: 10, borderColor: '#ccc'}}
        value={payloadData[index]?.sku}
        onChangeText={(text) =>
          setPayloadData((prev) => {
            const updated = [...prev];
            updated[index] = { ...updated[index], sku: text };
            return updated;
          })
        }
      />
      
      {payloadData[index]?.image_path?.sku ?
      <Image
        source={{uri: `${imageUrl}Images/${payloadData[index]?.image_path?.sku}`}}
        style={{
          height: 130,
          width: "100%",
          marginVertical: 10,
          resizeMode: "contain",
        }}
      />:null}
      {/* Fetch Button */}
      <Button
        mode="contained"
        compact
        style={{ flex: 1, marginBottom: 10, width: 130, backgroundColor: '#369aff' }}
        textColor="#fff"
        onPress={() => {
          if (!payloadData[index] || !payloadData[index].sku) {
            console.warn("SKU not available for this index");
            return;
          }
        
          const payload = {
            branch_id: "2057",
            sku: payloadData[index].sku,
          };
        
          postRequest("customervisit/SkuImage", payload, token)
            .then((response) => {
              console.log("response", response);
        
              // Check if image_path is valid
              if (response?.data?.image_path) {
                setPayloadData((prev) => {
                  const updated = [...prev];
                  updated[index] = {
                    ...updated[index],
                    image_path: {
                      ...updated[index]?.image_path,
                      sku: response.data.image_path,
                    },
                  };
                console.log("updated", updated);

                  return updated;
                }
              );
              } else {
                console.warn("Image path not found in response");
              }
            })
            .catch((error) => {
              console.error("Fetch error:", error);
            });
        }}
        
      >
        FETCH IMAGE
      </Button>

      {/* Sub Category Dropdown */}
      <DropDown
        data={
          payload.category_id === "2180"
            ? [
                { label: "JUPITER", value: "JUPITER" },
                { label: "PEP", value: "PEP" },
              ]
            : [
                { label: "APACHE", value: "APACHE" },
                { label: "SPORTS", value: "SPORTS" },
              ]
        }
        placeholder="Sub Category"
        value={payload.sub_category}
        onChangeText={(text) =>
          setPayloadData((prev) => {
            const updated = [...prev];
            updated[index] = { ...updated[index], sub_category: text };
            return updated;
          })
        }
        style={MyStyles.dropdown}
      />

      {/* Remarks Input */}
      <TextInput
        mode="outlined"
        label="Remarks"
        style={{ backgroundColor: "#fff", marginBottom: 10 }}
        value={payload.remarks}
        onChangeText={(text) =>
          setPayloadData((prev) => {
            const updated = [...prev];
            updated[index] = { ...updated[index], remarks: text };
            return updated;
          })
        }
      />

      {/* Payment Input */}
      <TextInput
  mode="outlined"
  label="Payment"
  style={{ backgroundColor: "#fff", marginBottom: 10 }}
  value={payload.payment}
  keyboardType="numeric" // 👈 ensures numeric keyboard on mobile
  onChangeText={(text) => {
    const numericText = text.replace(/[^0-9]/g, ''); // 👈 strips non-numeric characters
    setPayloadData((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], payment: numericText };
      return updated;
    });
  }}
/>


    
    </View>
  ))}
</View>


            </ScrollView>

            {/* Bottom Buttons */}
            <View
              style={[
                MyStyles.row,
                {
                  justifyContent: "space-between",
                  marginTop: 10,
                  gap: 8,
                  padding: 10,
                },
              ]}
            >
              <Button
                mode="contained"
                color="#DC143C"
                uppercase={false}
                compact
                onPress={() => {
                  setModal({ ...modal, upload: false, uploadNext: false, checkIn: false });
                  setUpload(null);
                  setCheckIn(false);
                  setPayloadData([]);
                  setCategory({
                    scooter: false,
                    motorcycle: false,
                    bike: false,
                  });
                  setImage([]);
                }}
                style={MyStyles.button}
              >
                CANCEL
              </Button>
              <Button mode="contained" onPress={() => {
                setModal({ ...modal, upload: true, uploadNext: false, checkIn: false });
              }} color="#007BFF" compact style={MyStyles.button}>
                BACK
              </Button>
              <Button mode="contained" color="#007BFF" style={MyStyles.button} compact 
              // onPress={async () => {
              //   if (!Array.isArray(payloadData) || payloadData.length === 0) {
              //     Alert.alert('Error', 'No data to upload.');
              //     return;
              //   }
            
              //   try {
              //     let allSuccessful = true;
            
              //     for (let item of payloadData) {
              //       const payload = {
              //         tran_id: 0,
              //         customer_id: item?.customer_id || 0,
              //         mobile: item?.mobile || '',
              //         full_name: item?.full_name || '',
              //         remarks: item?.remarks || '',
              //         sku: item?.sku || '',
              //         image_path: item?.image_path,
              //         appointment_date: item?.appointment_date || '',
              //         payment: item?.payment || '',
              //         sub_category: item?.sub_category || '',
              //         interest: item?.interest || 'Yes',
              //         staff_id: item?.staff_id || '1069',
              //         category_id: item?.category_id || '2180',
              //       };
            
              //       console.log("Uploading payload:", payload);
            
              //       const resp = await postRequest(
              //         'customervisit/insertCustomerUpload',
              //         payload,
              //         token
              //       );
            
              //       if (!(resp?.status === 200 && resp?.data && resp?.data[0]?.valid)) {
              //         allSuccessful = false;
              //         console.error("Upload failed for:", payload);
              //       }
              //     }
            
              //     if (allSuccessful) {
              //       Alert.alert('Success', 'All uploads successful!');
              //       setModal({ ...modal, upload: false, uploadNext: false, checkIn: false });
              //       setCheckIn(false);
              //       setUpload(null);
              //       setPayloadData([]);
              //       setCategory({
              //         scooter: false,
              //         motorcycle: false,
              //         bike: false,
              //       });
                    
              //     } else {
              //       Alert.alert('Partial Success', 'Some uploads failed. Please check logs.');
              //     }
              //   } catch (e) {
              //     console.error("Upload error:", e);
              //     Alert.alert('Error', 'Network or server error.');
              //   }
              // }}
              onPress={async () => {
                if (!Array.isArray(payloadData) || payloadData.length === 0) {
                  Alert.alert('Error', 'No data to upload.');
                  return;
                }
              
                try {
                  let allSuccessful = true;
              
                  for (let item of payloadData) {
                    const { image_path } = item;
              
                    // Collect all valid image URIs
                    const imageUris = [];
              
                    if (image_path?.choose) imageUris.push(image_path.choose);
                    if (Array.isArray(image_path?.add)) image_path.add.forEach(img => img && imageUris.push(img));
                    if (image_path?.fetchSku) imageUris.push(image_path.fetchSku);
                    if (image_path?.url) imageUris.push(image_path.url); // optional fallback
              
                    if (imageUris.length === 0) {
                      console.warn("No image URIs for item:", item);
                      continue;
                    }
              
                    for (let image of imageUris) {
                      const payload = {
                        tran_id: 0,
                        customer_id: item?.customer_id || 0,
                        mobile: item?.mobile || '',
                        full_name: item?.full_name || '',
                        remarks: item?.remarks || '',
                        sku: item?.sku || '',
                        image_path: image, // pass individual image URI
                        appointment_date: item?.appointment_date || '',
                        payment: item?.payment || '',
                        sub_category: item?.sub_category || '',
                        interest: item?.interest || 'Yes',
                        staff_id: item?.staff_id || '1069',
                        category_id: item?.category_id || '2180',
                      };
              
                      console.log("Uploading payload:", payload);
              
                      const resp = await postRequest(
                        'customervisit/insertCustomerUpload',
                        payload,
                        token
                      );
              
                      if (!(resp?.status === 200 && resp?.data && resp?.data[0]?.valid)) {
                        allSuccessful = false;
                        console.error("Upload failed for:", payload);
                      }
                    }
                  }
              
                  if (allSuccessful) {
                    Alert.alert('Success', 'All uploads successful!');
                    setModal({ ...modal, upload: false, uploadNext: false, checkIn: false });
                    setCheckIn(false);
                    setUpload(null);
                    setPayloadData([]);
                    setCategory({
                      scooter: false,
                      motorcycle: false,
                      bike: false,
                    });
                  setImage([]);

              
                  } else {
                    Alert.alert('Partial Success', 'Some uploads failed. Please check logs.');
                  }
                } catch (e) {
                  console.error("Upload error:", e);
                  Alert.alert('Error', 'Network or server error.');
                }
              }}
              
              
              >
                CONTINUE
              </Button>
            </View>
          </View>
        }
      />
     




      {/*------------ Notification Modal ------------------- */}
      <Portal>
        <Modal
          visible={modal.notification}
          dismissable={false}
          contentContainerStyle={{
            backgroundColor: "rgba(255,255,255,0.3)",
            //backgroundColor: "#FFF",
            width: "40%",
            height: "60%",
            alignSelf: "flex-end",
            borderRadius: 10,
            marginBottom: "auto",
            marginTop: 12,
          }}
        >
          <View style={{ flexDirection: "row", justifyContent: "flex-end" }}>
            <IconButton
              icon="close"
              size={10}
              color="#FFF"
              style={{ backgroundColor: "red" }}
              onPress={() => setModal({ ...modal, notification: false })}
            />
          </View>
          <View style={{ flex: 1, paddingHorizontal: 10 }}>
            <FlatList
              data={notifications}
              style={{ marginBottom: 10 }}
              renderItem={({ item, index }) => (
                <View
                  style={[
                    MyStyles.row,
                    {
                      //backgroundColor: "#FFF",
                      marginVertical: 1,
                      borderBottomColor: item.color,
                      borderBottomWidth: 2,
                    },
                  ]}
                >
                  <Surface
                    style={{
                      backgroundColor: item.color,
                      padding: 5,
                      width: 30,
                      height: 30,
                      justifyContent: "center",
                      alignSelf: "flex-end",
                    }}
                  >
                    <Text
                      style={{
                        textTransform: "uppercase",
                        fontSize: 30,
                        textAlign: "center",
                        color: "#FFF",
                      }}
                    >
                      {item.notification_type.slice(0, 1)}
                    </Text>
                  </Surface>
                  <View style={{ flexGrow: 1, padding: 5 }}>
                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                      <Text
                        style={{
                          color: "#FFF",
                        }}
                      >
                        {item.full_name}
                      </Text>
                      <Text
                        style={{
                          color: "#FFF",
                        }}
                      >
                        {item.mobile}
                      </Text>
                      <Text
                        style={{
                          color: "#FFF",
                        }}
                      >
                        {item.time}
                      </Text>
                      {/* <HTML  source={{ html: item.msg }} /> */}
                    </View>
                    {item.notification_type == "Feedback" && (
                      <>
                        <View style={{ display: "flex", flexDirection: "row" }}>
                          {[...Array(item.f_count)].map((el, index) => <Text key={index}>⭐</Text>)}
                        </View>
                        <View style={{ width: 250 }}>
                          <Text
                            style={{
                              color: "#FFF",
                              wordWrap: 'break-word'
                            }}
                          >
                            {item.f_service}
                          </Text>
                        </View>
                      </>
                    )}

                    {item.notification_type != "Feedback" && (
                      <Text
                        style={{
                          color: "#FFF",
                        }}
                      >
                        {item.notification_type}
                      </Text>

                    )}

                  </View>
                </View>
              )}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
        </Modal>
      </Portal>
    </View>
    // </ImageBackground>
  );
};

export default Dashboard;
