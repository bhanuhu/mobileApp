export const serviceUrl = "https://api.quicktagg.com/api/";

export const authUrl = "https://api.quicktagg.com/auth/";

export const imageUrl = "https://api.quicktagg.com/";